var class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node =
[
    [ "ResizeMode", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a13fd9f0f9bdeeb4a371f1f2fe2add0ce", [
      [ "PixelPerfect", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a13fd9f0f9bdeeb4a371f1f2fe2add0cea1ac6cfc61658bee4cbd8851821d9288d", null ],
      [ "FixedSize", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a13fd9f0f9bdeeb4a371f1f2fe2add0cea8bc66ef376d634aaa714727085b9acfe", null ]
    ] ],
    [ "ScreenGlobal", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a94e9af0b1c73f1b34ade526e075d3e1e", null ],
    [ "ScreenToLocal", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a62cd8982d66fdae5943351e3a600e2b8", null ],
    [ "manualHeight", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#aa80edccf7f45a894ac9ff5c7715f8c71", null ],
    [ "maximumHeight", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#ac43dc7b967111fc4440f845a8d720cc9", null ],
    [ "minimumHeight", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a1ded4b9fb56d807266d2d1a53b0c855a", null ],
    [ "resizeMode", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a978d6b7fca735d19527f92d83178af12", null ],
    [ "pixelSize", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#af1e20e9dad041000ef08dc0a7a1d4247", null ],
    [ "screenHeight", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a01d6f532b9ef17db8e9ad4246012832d", null ],
    [ "screenWidth", "class___n_a_m_e_s_p_a_c_e___1_1_mad_root_node.html#a7ca5b65aeb62594b4c554b0f5bab740d", null ]
];