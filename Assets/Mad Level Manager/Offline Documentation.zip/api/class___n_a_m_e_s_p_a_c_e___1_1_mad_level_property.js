var class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property =
[
    [ "SpecialType", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a64e3f208565bb9eb178272aefe5f9eeb", [
      [ "Regular", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a64e3f208565bb9eb178272aefe5f9eebad2203cb1237cb6460cbad94564e39345", null ],
      [ "Locked", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a64e3f208565bb9eb178272aefe5f9eebad0f2e5376298c880665077b565ffd7dd", null ],
      [ "Completed", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a64e3f208565bb9eb178272aefe5f9eeba07ca5050e697392c9ed47e6453f1453f", null ],
      [ "LevelNumber", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a64e3f208565bb9eb178272aefe5f9eebaac89dfeb8ab92af9f58be71048d42b74", null ]
    ] ],
    [ "Type", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a97324ffe5701b15a769c3c400697b616", [
      [ "Bool", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a97324ffe5701b15a769c3c400697b616ac26f15e86e3de4c398a8273272aba034", null ],
      [ "Integer", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a97324ffe5701b15a769c3c400697b616aa0faef0851b4294c06f2b94bb1cb2044", null ],
      [ "Float", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a97324ffe5701b15a769c3c400697b616a22ae0e2b89e5e3d477f988cc36d3272b", null ],
      [ "String", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a97324ffe5701b15a769c3c400697b616a27118326006d3829667a400ad23d5d98", null ]
    ] ],
    [ "_propertyEnabled", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a1ef3cfbf286d0fef1dc05c568cfee32f", null ],
    [ "showWhenDisabled", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a7138b01c7bd0c9a503d500dd4b015c41", null ],
    [ "showWhenEnabled", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a030de2f67ec4f3eeaecd68a077e4d0cc", null ],
    [ "textFromProperty", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a4fb07baeb7edaa2801919353fb17ccaf", null ],
    [ "textPropertyName", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a84b199ad4c7503a53406de9b4e3919fc", null ],
    [ "icon", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a37f638351d6f2b71a7b3a0fedee89ff7", null ],
    [ "propertyEnabled", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#ad6c38bea90a919ddd9687f12992ed75a", null ],
    [ "propertySet", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#a073b9f12fd330723497510d64b8f7716", null ],
    [ "specialType", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#ab22de419dc13fb52a26c39a3560a7b31", null ],
    [ "sprite", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property.html#acaaab470e11c520f05c2c55e67b94695", null ]
];