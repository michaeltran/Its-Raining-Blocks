var class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_text_tool =
[
    [ "font", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_text_tool.html#a947d856ab3fd9a07a80352420b1295b9", null ],
    [ "icon", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_text_tool.html#a335a77835e9f5f2535850e7e8a3cfc0c", null ],
    [ "name", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_text_tool.html#a893a352880f6aded53b7c109c3fe3186", null ]
];