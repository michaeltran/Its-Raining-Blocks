var class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char =
[
    [ "c", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char.html#a8787557d5c54227ce13b31b44e627ad0", null ],
    [ "chnl", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char.html#a6519dfddd253ef83a0102d8d313c38db", null ],
    [ "page", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char.html#a59984f852fb489ca40d4fbf3e9187b19", null ],
    [ "x", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char.html#a325cca475f3ffaa36013eda162aa1305", null ],
    [ "xAdvance", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char.html#a8d7d970d366cd7184946b762620223ca", null ],
    [ "xOffset", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_char.html#a2da18cf61bafcf09170b96601643961d", null ]
];