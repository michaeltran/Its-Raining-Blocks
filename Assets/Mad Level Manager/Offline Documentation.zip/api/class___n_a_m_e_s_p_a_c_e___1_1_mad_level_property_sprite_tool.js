var class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_sprite_tool =
[
    [ "icon", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_sprite_tool.html#a28e014e170e31bcbd8ac3974d0491ccd", null ],
    [ "name", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_sprite_tool.html#afc1f4e4e2ceec976ad4afdee98c1c259", null ],
    [ "texture", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_sprite_tool.html#a4181ad8c6ec5304e7e3648303a6a436b", null ]
];