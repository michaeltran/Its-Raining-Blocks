var class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_kerning =
[
    [ "amount", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_kerning.html#a8ee7caefff470ebe58859cefa7fb87d9", null ],
    [ "first", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_kerning.html#a01a29185624838c0830134d58560e65f", null ],
    [ "second", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_data_1_1_kerning.html#a1abe77f255c9142aa082795845d0909d", null ]
];