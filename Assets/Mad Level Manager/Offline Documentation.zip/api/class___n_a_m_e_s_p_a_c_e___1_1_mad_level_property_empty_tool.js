var class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_empty_tool =
[
    [ "icon", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_empty_tool.html#a9842c4d859318ac0de9a54c794256989", null ],
    [ "name", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_property_empty_tool.html#ad419e5f3833634b9a27498e57300b864", null ]
];