var namespaces =
[
    [ "MadLevelManager", "namespace_mad_level_manager.html", null ]
];