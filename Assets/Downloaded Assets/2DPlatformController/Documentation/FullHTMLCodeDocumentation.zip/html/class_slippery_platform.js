var class_slippery_platform =
[
    [ "DoAction", "class_slippery_platform.html#a11c50370015a25f770ff6bace5b41f9c", null ],
    [ "DoUpdate", "class_slippery_platform.html#a8f69dae7131ef7c061dcd753d79b85a1", null ],
    [ "drag", "class_slippery_platform.html#ac398bba02a08861a2bac9291619def92", null ]
];