var class_fall_damage =
[
    [ "CharacterAnimationEvent", "class_fall_damage.html#aafd0cd4a30f505f8ef7aeb80697ab676", null ],
    [ "controller", "class_fall_damage.html#a523c1357cdd4e1b6025141c7e57e29d4", null ],
    [ "fallDamageAction", "class_fall_damage.html#a149dcdaaa39e60722584ce9cd125d263", null ],
    [ "minSpeedForAction", "class_fall_damage.html#aee8b4d9534d4896eb7ca9b0436be1359", null ],
    [ "stunTime", "class_fall_damage.html#a6a235e053b54e5a5a3679fefa9720ab7", null ]
];