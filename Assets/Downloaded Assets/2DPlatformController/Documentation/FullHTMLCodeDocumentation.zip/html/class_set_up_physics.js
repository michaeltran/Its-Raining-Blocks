var class_set_up_physics =
[
    [ "character", "class_set_up_physics.html#afbfa922d939251d32c2580256765abdb", null ],
    [ "gravity", "class_set_up_physics.html#abd72b7a6c71787177095b3ebcb197dfa", null ],
    [ "ignoreColliderLayers", "class_set_up_physics.html#a3a0ff777427cdfa68b577090e9470026", null ],
    [ "timeScale", "class_set_up_physics.html#adc3147f96e8c8af477b5144434628cfd", null ]
];