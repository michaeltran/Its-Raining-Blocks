var class_slope_details =
[
    [ "allowSlopes", "class_slope_details.html#a9d61db3ae66f52b9e514f34b71c66de0", null ],
    [ "maxRotation", "class_slope_details.html#a18569a127d6a956e5650b5a15bf80bd7", null ],
    [ "rotationSpeed", "class_slope_details.html#a027f326b3af3c1f511ba75febb6daa15", null ],
    [ "slopeLookAhead", "class_slope_details.html#ac310455e94e4e50ff8c9a7003679ee65", null ]
];