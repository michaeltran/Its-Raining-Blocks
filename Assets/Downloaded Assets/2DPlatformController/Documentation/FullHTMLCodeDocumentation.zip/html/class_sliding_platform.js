var class_sliding_platform =
[
    [ "DoAction", "class_sliding_platform.html#a946d28b5b252fa0f1b34583781f97819", null ],
    [ "DoUpdate", "class_sliding_platform.html#a1a005a78930a69973fd848ae61dfa5c4", null ],
    [ "speed", "class_sliding_platform.html#a5ad2ddc738edf31c04aa07ba54a4d533", null ]
];