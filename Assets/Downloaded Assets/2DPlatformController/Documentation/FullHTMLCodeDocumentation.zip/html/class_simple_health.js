var class_simple_health =
[
    [ "Damage", "class_simple_health.html#addf05bf1efaee26f7ec28dcf9310ac49", null ],
    [ "Die", "class_simple_health.html#a350a2a7b535263f24c800aa5eea9196f", null ],
    [ "DoZeroHealthAction", "class_simple_health.html#aff254b77a41b04a62d3b446687d6b975", null ],
    [ "FallDamage", "class_simple_health.html#ae2ce23ff2912312070bda9aa695dc133", null ],
    [ "controller", "class_simple_health.html#a302e1769ac54a597a4de1e22d70e4c55", null ],
    [ "dieDelay", "class_simple_health.html#a2cf5865732d94c98e94abc63fcde806f", null ],
    [ "fallDamageAmount", "class_simple_health.html#a97ad867b1b9e4c272ccd771eff57f27e", null ],
    [ "fallDamageIsConstant", "class_simple_health.html#ac829b06c2a355b0c2905248002103cb0", null ],
    [ "health", "class_simple_health.html#a5f0d40a28f7aabfe7934c7856472d5ca", null ],
    [ "healthBar", "class_simple_health.html#a3e7a986e376e50dfa92211e40a379995", null ],
    [ "invulnerableTime", "class_simple_health.html#a4d24be1bcd2a2213b8c1fe19a25a2c62", null ],
    [ "invulnerableTimer", "class_simple_health.html#a14b085df7d2f3d25ec6543913b97d28d", null ],
    [ "maxHealth", "class_simple_health.html#a77d0e65626348e941aeca8c8a0f43ca3", null ],
    [ "stunTime", "class_simple_health.html#a7ca426127a243e32e35914aa21920933", null ],
    [ "zeroHealthAction", "class_simple_health.html#a4d1103057d6e32e503a8c51baf535ec4", null ],
    [ "Health", "class_simple_health.html#a09ed134433c6357dc115e2febb31c200", null ],
    [ "HealthAsPercentage", "class_simple_health.html#a0e0d4474d7c207454e464f0abc701f8a", null ],
    [ "IsInvulnerable", "class_simple_health.html#ad41dbbef8feec80d19630ad911093af3", null ],
    [ "MaxHealth", "class_simple_health.html#aae65df708c14f7e0ea149783a452a592", null ]
];