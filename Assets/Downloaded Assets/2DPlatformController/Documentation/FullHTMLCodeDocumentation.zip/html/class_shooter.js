var class_shooter =
[
    [ "projectilePrefab", "class_shooter.html#a9684b85835fa2311e9d3bdf31778b5d5", null ]
];