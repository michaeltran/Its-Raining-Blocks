var class_touch_controller =
[
    [ "allowRun", "class_touch_controller.html#abb74e01fba808c4560cca2890e7bdaea", null ],
    [ "buttonLayer", "class_touch_controller.html#a87d79d7ed311a2fb6357ec36d7158936", null ],
    [ "buttons", "class_touch_controller.html#a5050541d39d289798f830732828ca42e", null ],
    [ "predictiveMode", "class_touch_controller.html#aa3fceaba46db99fd87add7f17cc7cbc7", null ],
    [ "uiCamera", "class_touch_controller.html#a732f587a9b32b90bc731ddbfe6cb9477", null ],
    [ "xButtonValue", "class_touch_controller.html#a089f238ec698110bbf8a7e21da86eebf", null ],
    [ "yButtonValue", "class_touch_controller.html#a11d2d4706fadd302a077e2af82f06081", null ]
];