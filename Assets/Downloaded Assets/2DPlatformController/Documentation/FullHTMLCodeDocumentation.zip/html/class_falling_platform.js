var class_falling_platform =
[
    [ "DoAction", "class_falling_platform.html#a6f2ced9e7fc92c9210c1dba2304bc9d7", null ],
    [ "ParentOnStand", "class_falling_platform.html#a34d014e67f8c83d5989486042febb99b", null ],
    [ "fallDelay", "class_falling_platform.html#aa2e523a6580713f21832f994b2b30663", null ],
    [ "velocityForFall", "class_falling_platform.html#a1f0c2617bc2cd14bb0d1288948341086", null ]
];