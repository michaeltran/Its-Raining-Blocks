var class_ladder =
[
    [ "control", "class_ladder.html#afbd4380a5e4eb3045dcbedca313766f8", null ],
    [ "LedgeClimbHeight", "class_ladder.html#a03b01bc8a96d86022ae74b69bff4a3b3", null ]
];