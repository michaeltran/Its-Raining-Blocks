var class_ledge_details =
[
    [ "autoGrab", "class_ledge_details.html#ac55003184feaba69f09b254a338b586d", null ],
    [ "autoGrabDistance", "class_ledge_details.html#a20629695dea5c3735ba76414116b728c", null ],
    [ "canLedgeHang", "class_ledge_details.html#ac71ecec11f623c9766469366bdd91a89", null ],
    [ "climbOffset", "class_ledge_details.html#a098ef9999fd9862640318058fa0d79c9", null ],
    [ "climbTime", "class_ledge_details.html#a778eca0af74df3baacea2416ed5063bf", null ],
    [ "edgeDetectionOffset", "class_ledge_details.html#aee2ab9953254abe5e98ee1775c401f4d", null ],
    [ "graspLeeway", "class_ledge_details.html#a85672022beca45db0b4bd017a9172d6d", null ],
    [ "graspPoint", "class_ledge_details.html#adb2f6b732403e98a30f3c5fad8320bb2", null ],
    [ "hangOffset", "class_ledge_details.html#a1d501fe451119e666d8ded91e98dbb21", null ],
    [ "jumpOnlyInOppositeDirection", "class_ledge_details.html#a0004776a98d7376eed94fa6ee0a57127", null ],
    [ "jumpVelocity", "class_ledge_details.html#ab3e423180996f4fa2b3a6f77e056ddc7", null ],
    [ "ledgeDropTime", "class_ledge_details.html#ae5dcbd227ccfc7f385d1ca164fa9b05e", null ],
    [ "oppositeDirectionTime", "class_ledge_details.html#afa8be371fe834fdda1e7e0b6658ca97b", null ],
    [ "transitionTime", "class_ledge_details.html#a5ca380e2131f035209c7ee981088c743", null ]
];