var class_direction_checker =
[
    [ "SwitchColliders", "class_direction_checker.html#ae1b59929f45756fc672f5b3d87fb48f0", null ],
    [ "UpdateDirection", "class_direction_checker.html#ad355c3b2f255a5fa22b25931306d0023", null ],
    [ "startingDirection", "class_direction_checker.html#adc9f06f9e0bd7f6512ca2afdf7bf323b", null ],
    [ "CurrentDirection", "class_direction_checker.html#a79325d326fc3c9077231054adebf18a7", null ]
];