var class_hit_box =
[
    [ "Collect", "class_hit_box.html#a076a7f597e7b041b4d3a1c5e8a050602", null ],
    [ "Damage", "class_hit_box.html#a72a98cf2be8bf23544c556d39ff01dd5", null ],
    [ "simplehealth", "class_hit_box.html#a395d0d5574b20e32911b1dd249a44699", null ]
];