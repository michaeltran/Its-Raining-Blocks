var class_projectile =
[
    [ "minX", "class_projectile.html#a9810903da08dc524f18e094d07b9cba0", null ],
    [ "speed", "class_projectile.html#a08b05673dcd2da844c04ad812f04b3aa", null ]
];