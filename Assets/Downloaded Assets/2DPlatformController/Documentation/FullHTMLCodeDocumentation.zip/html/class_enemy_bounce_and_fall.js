var class_enemy_bounce_and_fall =
[
    [ "Kill", "class_enemy_bounce_and_fall.html#a8ddf53f42722d12b72c80f8f120a3d8a", null ],
    [ "KillFromAbove", "class_enemy_bounce_and_fall.html#a57ccd0caf25971a230c183cbe850ccbc", null ],
    [ "KillFromBelow", "class_enemy_bounce_and_fall.html#a6f01aad69207f9bf6774172b0e0d02f0", null ]
];