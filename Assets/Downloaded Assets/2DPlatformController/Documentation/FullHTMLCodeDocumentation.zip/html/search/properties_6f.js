var searchData=
[
  ['overrideanimation',['overrideAnimation',['../class_platform.html#afcd2bd2350f8a8f5ed84d87f3fe1b544',1,'Platform']]],
  ['overridex',['overrideX',['../class_platform.html#af676450353dc3496e74023c78b89b126',1,'Platform']]],
  ['overridey',['overrideY',['../class_platform.html#a14df9f726b5fc848f95fbab39fca8b38',1,'Platform']]]
];
