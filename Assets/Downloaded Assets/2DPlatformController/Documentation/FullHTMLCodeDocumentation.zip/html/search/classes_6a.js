var searchData=
[
  ['jumpdetails',['JumpDetails',['../class_jump_details.html',1,'']]],
  ['jumponhead',['JumpOnHead',['../class_jump_on_head.html',1,'']]]
];
