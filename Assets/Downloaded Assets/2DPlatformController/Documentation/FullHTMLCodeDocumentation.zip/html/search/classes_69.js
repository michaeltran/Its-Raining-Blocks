var searchData=
[
  ['ienemy',['IEnemy',['../interface_i_enemy.html',1,'']]]
];
