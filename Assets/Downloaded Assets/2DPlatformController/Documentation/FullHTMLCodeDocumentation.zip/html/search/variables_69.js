var searchData=
[
  ['ignoredsidecollidershigherthan',['ignoredSideCollidersHigherThan',['../class_crouch_details.html#ac20b9b467138b53d36b8e8598f40f755',1,'CrouchDetails']]],
  ['invulnerabletime',['invulnerableTime',['../class_simple_health.html#a4d24be1bcd2a2213b8c1fe19a25a2c62',1,'SimpleHealth']]]
];
