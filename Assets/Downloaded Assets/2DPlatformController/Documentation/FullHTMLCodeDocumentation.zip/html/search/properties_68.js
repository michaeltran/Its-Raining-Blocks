var searchData=
[
  ['health',['Health',['../class_simple_health.html#a09ed134433c6357dc115e2febb31c200',1,'SimpleHealth']]],
  ['healthaspercentage',['HealthAsPercentage',['../class_simple_health.html#a0e0d4474d7c207454e464f0abc701f8a',1,'SimpleHealth']]]
];
