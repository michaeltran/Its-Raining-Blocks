var searchData=
[
  ['currentdirection',['CurrentDirection',['../class_direction_checker.html#a79325d326fc3c9077231054adebf18a7',1,'DirectionChecker.CurrentDirection()'],['../class_raycast_character_controller.html#ab7cf685651a506d300f12387b7a0eb35',1,'RaycastCharacterController.CurrentDirection()']]]
];
