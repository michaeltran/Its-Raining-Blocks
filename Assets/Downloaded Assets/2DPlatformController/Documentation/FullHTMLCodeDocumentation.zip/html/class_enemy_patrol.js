var class_enemy_patrol =
[
    [ "Bobble", "class_enemy_patrol.html#acd0459f172486d93dc61525d9034836f", null ],
    [ "Kill", "class_enemy_patrol.html#a312dc1ff5a49936f81d13790ab13e249", null ],
    [ "KillFromAbove", "class_enemy_patrol.html#a6b0583ee713f9a8858901832938dff76", null ],
    [ "KillFromBelow", "class_enemy_patrol.html#a5cc503775fdda4a1020e0e1063cc50bf", null ],
    [ "bobble", "class_enemy_patrol.html#a848fac32fa0a27349f57536862b745f8", null ],
    [ "bounceVelocity", "class_enemy_patrol.html#a0082d35e6e1b79454887aae37c3fda33", null ],
    [ "enemyName", "class_enemy_patrol.html#abe0ee6b7e032ee0832a670647237f99c", null ],
    [ "maxX", "class_enemy_patrol.html#a9044faf66f9a55104a49c848b8f69263", null ],
    [ "minX", "class_enemy_patrol.html#a9b11cd167dd6e786283d420cd3d02ea4", null ],
    [ "speed", "class_enemy_patrol.html#a23cfe21b7240a1587504460864cb4bfc", null ],
    [ "stunTime", "class_enemy_patrol.html#aa87fe3d1ad5cbe4a673a47b86fd18245", null ]
];