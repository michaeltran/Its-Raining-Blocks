var class_jump_details =
[
    [ "canDoubleJump", "class_jump_details.html#a04cae1de2026ca1504c0b5c83e5cf446", null ],
    [ "doubleJumpVelocity", "class_jump_details.html#afc78962b63cf3cfd9916fb6169c9be4b", null ],
    [ "drag", "class_jump_details.html#a56076fc31faebacc715218fdbef07c01", null ],
    [ "fallVelocity", "class_jump_details.html#abe0c927c5e03a0a2bee54ffa3fd1c239", null ],
    [ "jumpFrameVelocity", "class_jump_details.html#aaff75866ca985c277ba3d5eca017ea43", null ],
    [ "jumpHeldTime", "class_jump_details.html#af1f0ef4697f3d03adcbb7c279c5e1312", null ],
    [ "jumpTimer", "class_jump_details.html#a20dc1cfc1800e8207f5d7e4d2f3d9b7b", null ],
    [ "jumpVelocity", "class_jump_details.html#ad2b6e57b467322620742cf05c01bedd1", null ]
];