var interface_i_enemy =
[
    [ "Kill", "interface_i_enemy.html#a404bc53fb90ac0273c33659d680a5fdb", null ],
    [ "KillFromAbove", "interface_i_enemy.html#a0d07e857363310baf2fc346234caa575", null ],
    [ "KillFromBelow", "interface_i_enemy.html#ada2c0563d7e9ccbda8328f28a50f6c75", null ]
];