var class_enemy_bounce_and_fall_input =
[
    [ "bounceVelocity", "class_enemy_bounce_and_fall_input.html#a137e5ac9b6087aeb6f2eb68b1a719514", null ],
    [ "direction", "class_enemy_bounce_and_fall_input.html#a8132c92d716efabb4feef60ff82e7ce9", null ],
    [ "senseDistance", "class_enemy_bounce_and_fall_input.html#aabbd9170600fa35a18a1d613eeb67cc1", null ],
    [ "stunTime", "class_enemy_bounce_and_fall_input.html#a0a46f173136a8b9b8b12f04fcbb8947d", null ]
];