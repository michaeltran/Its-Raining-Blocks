var class_float =
[
    [ "controller", "class_float.html#a4f7290364f0b29edcaa2e110b00b5dce", null ],
    [ "floatFactor", "class_float.html#ac285c5cfb4f90b59ce47fc5d5d8a1de0", null ],
    [ "input", "class_float.html#a290ced8bd404041eeafffd7b07240003", null ]
];