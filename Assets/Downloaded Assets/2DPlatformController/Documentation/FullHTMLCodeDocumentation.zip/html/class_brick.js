var class_brick =
[
    [ "DoAction", "class_brick.html#a23698ffc1aef2663fac9df368eec4936", null ],
    [ "myCollider", "class_brick.html#a835576bccf3415db0b3fbdd1c3e3adf7", null ],
    [ "myRenderer", "class_brick.html#a8049043ee360d69370b0d774b8c4adf0", null ],
    [ "particles", "class_brick.html#a90325e687e513c664c91667d38fdd284", null ]
];