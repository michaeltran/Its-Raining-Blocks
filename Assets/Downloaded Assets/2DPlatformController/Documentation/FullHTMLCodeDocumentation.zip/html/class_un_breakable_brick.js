var class_un_breakable_brick =
[
    [ "DoAction", "class_un_breakable_brick.html#a07d5d822c5a8e6214ee42f30fa44e2e9", null ],
    [ "hitMaterial", "class_un_breakable_brick.html#ab4393212d2d29d5a83cf7e1edc3e9cfe", null ],
    [ "spawnActivateTime", "class_un_breakable_brick.html#ab8ca978b5a9ce9eb158a23362952b746", null ],
    [ "spawnForce", "class_un_breakable_brick.html#a560a55aec8c61a426feede158fb0a7ce", null ],
    [ "spawnGameObject", "class_un_breakable_brick.html#a8c1423dfab63c9dd8c281faaa42d5add", null ]
];