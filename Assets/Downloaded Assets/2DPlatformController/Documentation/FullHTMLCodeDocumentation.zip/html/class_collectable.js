var class_collectable =
[
    [ "myRenderer", "class_collectable.html#a209fb22452194226ddebb3a8173499f0", null ],
    [ "particles", "class_collectable.html#a8f26b18018ad7cc98c8ee1e78ea898d8", null ]
];