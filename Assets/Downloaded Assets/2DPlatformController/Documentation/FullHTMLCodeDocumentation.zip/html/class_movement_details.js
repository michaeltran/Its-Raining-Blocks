var class_movement_details =
[
    [ "acceleration", "class_movement_details.html#a367a408bc98515795aa4cbccce566151", null ],
    [ "drag", "class_movement_details.html#a7b7f55910170ee20db102f8f6b5fda9d", null ],
    [ "runSpeed", "class_movement_details.html#abb00c6f82e3ce9a5638c092c0eabf7b6", null ],
    [ "skinSize", "class_movement_details.html#a1f02f739db943e30e98a4e33f56f841f", null ],
    [ "terminalVelocity", "class_movement_details.html#a7db917f205353d7f61538af4b07e5545", null ],
    [ "walkSpeed", "class_movement_details.html#adadf0b70f3e269e11d85da8126e91da3", null ]
];