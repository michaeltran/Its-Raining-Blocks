var class_crouch_details =
[
    [ "canCrouch", "class_crouch_details.html#a634d547deaad109e2dbcb710188ae9bc", null ],
    [ "canCrouchJump", "class_crouch_details.html#aad2f37d64a9fb34a73087d850ce83203", null ],
    [ "canCrouchSlide", "class_crouch_details.html#a5462b8294aa25e5c51f55a9ba6750f02", null ],
    [ "headDetectionDistance", "class_crouch_details.html#a91722d794ee1146ce4f0834ef38d28ad", null ],
    [ "heightReductionFactor", "class_crouch_details.html#aad718c7c750d96a416b9d8f47627d248", null ],
    [ "ignoredSideCollidersHigherThan", "class_crouch_details.html#ac20b9b467138b53d36b8e8598f40f755", null ],
    [ "minVelocityForSlide", "class_crouch_details.html#af8322bc85f253bee417b4043e92938f9", null ],
    [ "minVelocityForStopSlide", "class_crouch_details.html#a4268caac92928832aafaa3fa92ba2851", null ],
    [ "slideDrag", "class_crouch_details.html#a0ad4e79f7f489ade766cbec6ae3c1373", null ],
    [ "useHeightReduction", "class_crouch_details.html#acaabd5c108ed247f067a92978e530aaf", null ]
];