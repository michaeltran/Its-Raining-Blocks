var hierarchy =
[
    [ "CharacterControllerEventDelegate", "class_character_controller_event_delegate.html", null ],
    [ "ClimbDetails", "class_climb_details.html", null ],
    [ "CrouchDetails", "class_crouch_details.html", null ],
    [ "Editor", null, [
      [ "RaycastCharacterControllerEditor", "class_raycast_character_controller_editor.html", null ]
    ] ],
    [ "EditorWindow", null, [
      [ "LadderWizardEditorWindow", "class_ladder_wizard_editor_window.html", null ]
    ] ],
    [ "IEnemy", "interface_i_enemy.html", [
      [ "EnemyAIController", "class_enemy_a_i_controller.html", null ],
      [ "EnemyBounceAndFall", "class_enemy_bounce_and_fall.html", null ],
      [ "EnemyPatrol", "class_enemy_patrol.html", null ]
    ] ],
    [ "JumpDetails", "class_jump_details.html", null ],
    [ "LedgeDetails", "class_ledge_details.html", null ],
    [ "MonoBehaviour", null, [
      [ "AnimationLogger", "class_animation_logger.html", null ],
      [ "CameraFollow", "class_camera_follow.html", null ],
      [ "Collectable", "class_collectable.html", null ],
      [ "DirectionChecker", "class_direction_checker.html", null ],
      [ "EnemyPatrol", "class_enemy_patrol.html", null ],
      [ "FallDamage", "class_fall_damage.html", null ],
      [ "Float", "class_float.html", null ],
      [ "HeroAnimator", "class_hero_animator.html", null ],
      [ "HitBox", "class_hit_box.html", null ],
      [ "JumpOnHead", "class_jump_on_head.html", null ],
      [ "LadderControl", "class_ladder_control.html", null ],
      [ "ModelAnimator", "class_model_animator.html", null ],
      [ "Platform", "class_platform.html", [
        [ "BackAndForthPlatform", "class_back_and_forth_platform.html", null ],
        [ "Brick", "class_brick.html", null ],
        [ "DecayingPlatform", "class_decaying_platform.html", null ],
        [ "FallingPlatform", "class_falling_platform.html", null ],
        [ "KillBox", "class_kill_box.html", null ],
        [ "Ladder", "class_ladder.html", [
          [ "LadderCollider", "class_ladder_collider.html", [
            [ "TopStepPlatform", "class_top_step_platform.html", null ]
          ] ]
        ] ],
        [ "PassthroughPlatform", "class_passthrough_platform.html", null ],
        [ "RespawnPoint", "class_respawn_point.html", null ],
        [ "Rope", "class_rope.html", [
          [ "RopeCollider", "class_rope_collider.html", null ]
        ] ],
        [ "SlidingPlatform", "class_sliding_platform.html", null ],
        [ "SlipperyPlatform", "class_slippery_platform.html", null ],
        [ "SpringboardPlatform", "class_springboard_platform.html", null ],
        [ "UnBreakableBrick", "class_un_breakable_brick.html", null ],
        [ "UpAndDownPlatform", "class_up_and_down_platform.html", null ]
      ] ],
      [ "Projectile", "class_projectile.html", null ],
      [ "RaycastCharacterController", "class_raycast_character_controller.html", [
        [ "EnemyBounceAndFall", "class_enemy_bounce_and_fall.html", null ]
      ] ],
      [ "RaycastCharacterInput", "class_raycast_character_input.html", [
        [ "EnemyAIController", "class_enemy_a_i_controller.html", null ],
        [ "EnemyBounceAndFallInput", "class_enemy_bounce_and_fall_input.html", null ],
        [ "SimpleCharacterInput", "class_simple_character_input.html", null ],
        [ "StandardMobileInput", "class_standard_mobile_input.html", null ],
        [ "TouchController", "class_touch_controller.html", null ]
      ] ],
      [ "RopeControl", "class_rope_control.html", null ],
      [ "SetUpPhysics", "class_set_up_physics.html", null ],
      [ "Shooter", "class_shooter.html", null ],
      [ "SimpleHealth", "class_simple_health.html", null ],
      [ "SimpleHealthBarUI", "class_simple_health_bar_u_i.html", null ],
      [ "TouchControllerButton", "class_touch_controller_button.html", null ]
    ] ],
    [ "MovementDetails", "class_movement_details.html", null ],
    [ "RaycastCollider", "class_raycast_collider.html", null ],
    [ "SlopeDetails", "class_slope_details.html", null ],
    [ "WallDetails", "class_wall_details.html", null ]
];