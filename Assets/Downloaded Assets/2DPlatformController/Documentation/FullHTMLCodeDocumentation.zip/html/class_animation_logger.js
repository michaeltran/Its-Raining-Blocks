var class_animation_logger =
[
    [ "CharacterAnimationEvent", "class_animation_logger.html#a1e61130487b3006d1ae787799295314b", null ],
    [ "controller", "class_animation_logger.html#a40350eea96c0368ed4e565ea88da108c", null ]
];