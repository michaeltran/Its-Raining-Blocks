var class_platform =
[
    [ "DoAction", "class_platform.html#a8edd06dca855ac52ecc6b8ac4f8fd953", null ],
    [ "DoStart", "class_platform.html#a132ad6ba5c6171fa6da60adf546ebb1b", null ],
    [ "DoUpdate", "class_platform.html#a7b023a83a4383d942f787d3d599f9619", null ],
    [ "GetAnimationState", "class_platform.html#a18c2c40da5ba71d242f125724797a889", null ],
    [ "Move", "class_platform.html#a9c3758326f5a839cb9ff2fdc44208c4c", null ],
    [ "ParentOnStand", "class_platform.html#ac66a33088a8b22f5350f9c43d5e0b95e", null ],
    [ "myTransform", "class_platform.html#a46bedb7b515d7b1e824f5ed653b07aba", null ],
    [ "overrideAnimation", "class_platform.html#afcd2bd2350f8a8f5ed84d87f3fe1b544", null ],
    [ "overrideX", "class_platform.html#af676450353dc3496e74023c78b89b126", null ],
    [ "overrideY", "class_platform.html#a14df9f726b5fc848f95fbab39fca8b38", null ],
    [ "velocity", "class_platform.html#aacbf5307b8b627c0cdb76f68e8885fc3", null ]
];