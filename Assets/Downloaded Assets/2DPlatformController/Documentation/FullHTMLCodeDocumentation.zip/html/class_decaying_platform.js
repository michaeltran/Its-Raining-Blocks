var class_decaying_platform =
[
    [ "DoAction", "class_decaying_platform.html#a832b60a4cff5676607c27d2fc248d69a", null ],
    [ "decayTime", "class_decaying_platform.html#a76f17ffaa61da85ea897db3006bab86a", null ]
];