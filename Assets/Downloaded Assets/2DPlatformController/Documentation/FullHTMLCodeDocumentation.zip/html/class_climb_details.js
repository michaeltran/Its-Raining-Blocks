var class_climb_details =
[
    [ "allowClimbing", "class_climb_details.html#aaa660c96cd725a97bb98bb308cca357e", null ],
    [ "autoStick", "class_climb_details.html#a86313adc879294767a1d92dc63610181", null ],
    [ "climbOffset", "class_climb_details.html#ac13be4a45046f03c9f80018410199ed7", null ],
    [ "climbTopAnimationTime", "class_climb_details.html#a0fd7033502c31d78ebd653c2cb250ddc", null ],
    [ "climbTopDownAnimationTime", "class_climb_details.html#a5d70a1907a8ebfec2a962da3e75b0d28", null ],
    [ "collidersRequired", "class_climb_details.html#a5f80ef87a5f7f7a4fedc9fe905f6b11e", null ],
    [ "horizontalSpeed", "class_climb_details.html#a0755b88136f912dc68126cc266f1026c", null ],
    [ "ropeSwingForce", "class_climb_details.html#ad219e4227eb0ada21eb984df4e032e07", null ],
    [ "ropeVelocityFactor", "class_climb_details.html#ad8bf55fd00fb963a1ac0079d796c5bcb", null ],
    [ "speed", "class_climb_details.html#ac299d38ca2be6edc66b9de47e331efd9", null ]
];