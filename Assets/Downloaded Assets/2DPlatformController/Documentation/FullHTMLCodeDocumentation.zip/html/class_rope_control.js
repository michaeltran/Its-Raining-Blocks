var class_rope_control =
[
    [ "_lastSwingDirection", "class_rope_control.html#addedfbea8aba51d65f573ef895d2eeed", null ],
    [ "canClimb", "class_rope_control.html#a588ae7387800797dd07cbaff8bce214c", null ],
    [ "hasClimbed", "class_rope_control.html#a473abddf7ac0a8fa40cff6ca7729207a", null ],
    [ "hasSwung", "class_rope_control.html#aa51a72792e55a24978fc1463508573e1", null ],
    [ "jumpFlattenFactor", "class_rope_control.html#a4a7fe5a3eeaf1db818c7ce72187bbbe3", null ],
    [ "ropeVelocityFactor", "class_rope_control.html#aa1ee15f5835fcc08a244dae16c7bf669", null ],
    [ "swingTime", "class_rope_control.html#acad14c4fe1408dc6a42c4060e1891647", null ],
    [ "LastSwingDirection", "class_rope_control.html#abb1490e95ce27afd124b4ea008195e08", null ]
];