var class_passthrough_platform =
[
    [ "DoAction", "class_passthrough_platform.html#ae2614110a397c76a46acc7bd30d38e65", null ],
    [ "fallThroughTime", "class_passthrough_platform.html#a2a7714fd1989a7e15e999dbb6f73960d", null ],
    [ "requireJump", "class_passthrough_platform.html#a288413ae97117d35d592c18bc37022d7", null ]
];