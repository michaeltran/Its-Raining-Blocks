var class_wall_details =
[
    [ "canWallJump", "class_wall_details.html#aa6e849ccaa73589530a518aa42bf75d2", null ],
    [ "canWallSlide", "class_wall_details.html#a37c2a3bb1053b880ee09c7e22d1a3ebb", null ],
    [ "easyWallJump", "class_wall_details.html#a2cb08fdc65b09a9b12cd8240ac20112f", null ],
    [ "edgeDetectionOffset", "class_wall_details.html#a734f5d793100d8176c3d937b82e42c73", null ],
    [ "oppositeDirectionTime", "class_wall_details.html#a9d0a2868e84fdeed3b597844a9be77fc", null ],
    [ "wallJumpOnlyInOppositeDirection", "class_wall_details.html#a26b5dde77e59cba6d277b53f587577d6", null ],
    [ "wallJumpTime", "class_wall_details.html#a3e40b6bb9cab8538a9f246432671bb8c", null ],
    [ "wallSlideAdditionalDistance", "class_wall_details.html#ab0e4f5a902db271faf7d9ee742b3e7e3", null ],
    [ "wallSlideGravityFactor", "class_wall_details.html#a397e893df5750851b00d74fdd676ade5", null ]
];