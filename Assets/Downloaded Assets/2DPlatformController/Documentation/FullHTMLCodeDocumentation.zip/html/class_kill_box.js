var class_kill_box =
[
    [ "DoAction", "class_kill_box.html#a7906b079382f416953ab23dc54ebcb6f", null ]
];