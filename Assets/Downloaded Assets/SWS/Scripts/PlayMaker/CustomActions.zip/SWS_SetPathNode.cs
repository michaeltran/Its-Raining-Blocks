﻿using System.Collections;
using UnityEngine;

//replaces a waypoint of a path by using an index position
//and sets the corresponding waypoint gameobject to the new gameobject,
//destroying the old waypoint
namespace HutongGames.PlayMaker.Actions
{

    [ActionCategory("Simple Waypoint System")]
    [Tooltip("Sets the desired waypoint of a path.")]
    public class SetPathNode : FsmStateAction
    {
        [RequiredField]
        [ObjectType(typeof(PathManager))]
        [Tooltip("Path manager component")]
        public FsmObject pathObject;

        [RequiredField]
        [UIHint(UIHint.FsmInt)]
        [Tooltip("Waypoint index")]
        public FsmInt wpIndex;

        [RequiredField]
        [UIHint(UIHint.Variable)]
        [Tooltip("Waypoint gameobject")]
        public FsmGameObject waypoint;


        public override void Reset()
        {
            pathObject = null;
            wpIndex = null;
            waypoint = null;
        }


        public override void OnEnter()
        {
            SetNode();

            Finish();
        }

        void SetNode()
        {
            PathManager path = pathObject.Value as PathManager;

            if (wpIndex.Value >= path.waypoints.Length - 1)
            {
                wpIndex.Value = path.waypoints.Length - 1;
                waypoint.Value.name = "WaypointEnd";
            }
            else if (wpIndex.Value == 0)
                waypoint.Value.name = "WaypointStart";
            else
                waypoint.Value.name = "Waypoint";

            waypoint.Value.transform.parent = path.transform;
            GameObject oldWaypoint = path.waypoints[wpIndex.Value].gameObject;
            path.waypoints[wpIndex.Value] = waypoint.Value.transform;
            Object.Destroy(oldWaypoint);
        }
    }
}
