﻿using System.Collections;
using UnityEngine;

//gets a waypoint of a path by using an index position
//and returns the corresponding waypoint gameobject
namespace HutongGames.PlayMaker.Actions
{

    [ActionCategory("Simple Waypoint System")]
    [Tooltip("Gets the desired waypoint of a path.")]
    public class GetPathNode : FsmStateAction
    {
        [RequiredField]
        [ObjectType(typeof(PathManager))]
        [Tooltip("Path manager component")]
        public FsmObject pathObject;

        [RequiredField]
        [UIHint(UIHint.FsmInt)]
        [Tooltip("Waypoint index")]
        public FsmInt wpIndex;

        [RequiredField]
        [UIHint(UIHint.Variable)]
        [Tooltip("Waypoint gameobject")]
        public FsmGameObject waypoint;


        public override void Reset()
        {
            pathObject = null;
            wpIndex = null;
            waypoint = null;
        }


        public override void OnEnter()
        {
            GetNode();

            Finish();
        }

        void GetNode()
        {
            PathManager path = pathObject.Value as PathManager;

            if (wpIndex.Value > path.waypoints.Length - 1)
                wpIndex.Value = path.waypoints.Length - 1;

            waypoint.Value = path.waypoints[wpIndex.Value].gameObject;
        }
    }
}
