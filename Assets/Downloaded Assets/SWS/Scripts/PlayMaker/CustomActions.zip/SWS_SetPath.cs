﻿using System.Collections;
using UnityEngine;

//sets the path of a walker object that uses iMove or hoMove
//by calling its SetPath() method with a path name or path component as parameter
namespace HutongGames.PlayMaker.Actions
{

    [ActionCategory("Simple Waypoint System")]
    [Tooltip("Sets the path of a movement component.")]
    public class SetPath : FsmStateAction
    {
        [RequiredField]
        public FsmOwnerDefault gameObject;

        [UIHint(UIHint.FsmString)]
        [Tooltip("Path name")]
        public FsmString pathName;

        [ObjectType(typeof(PathManager))]
        [Tooltip("Path manager component")]
        public FsmObject pathObject;


        public override void Reset()
        {
            gameObject = null;
            pathObject = null;
            pathName = null;
        }


        public override void OnEnter()
        {
            PassPath();

            Finish();
        }

        void PassPath()
        {
            var go = Fsm.GetOwnerDefaultTarget(gameObject);
            if (go == null) return;

            if (pathName.Value != "")
                go.SendMessage("SetPath", WaypointManager.Paths[pathName.Value]);
            else if (pathObject != null)
                go.SendMessage("SetPath", pathObject.Value as PathManager);
        }
    }
}
